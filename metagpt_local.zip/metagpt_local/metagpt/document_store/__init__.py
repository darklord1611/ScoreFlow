#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : 2023/5/25 10:20
@Author  : alexanderwu
@File    : __init__.py
"""

from metagpt.document_store.faiss_store import FaissStore

__all__ = ["FaissStore"]
