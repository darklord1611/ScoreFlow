#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Desc   :

# For Android Assistant Agent
ADB_EXEC_FAIL = "FAILED"
